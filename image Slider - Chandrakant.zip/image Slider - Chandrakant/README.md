

 How to Run

1. Ensure all files are in the same directory.
2. Replace the placeholder image URLs in `ischan.js` with your own image paths is you want your images to placed in it.I have publicly placed in images folder .
3. Open `index.html` in a web browser.
4. The automatic slideshow pauses briefly when navigation buttons are clicked and resumes afterward.
4. 

Features
1)Displays 5 images in a carousel format.
2) Supports "Previous" and "Next" navigation buttons.
3)Loops back to the first image after the last one (and vice versa).
4)Automatically transitions to the next image every 3 seconds.
5)Responsive design for desktop and mobile devices.




HTML,CSS,JS , ARRAY OF IMAGES ,Automatic Slideshow: Add an option to make the slider automatically transition to the
next image after a certain interval (e.g., every 3 seconds).


JavaScript Functionality: Implement the JavaScript logic for the image slider. You should
create functions to:
● Display the first image when the page loads.
● Allow users to click on "Next" and "Previous" buttons to navigate through the
images.
● Loop back to the first image after reaching the last one.


images 
![alt text](<Screenshot (139).png>)


![alt text](<Screenshot (138).png>)


![alt text](<Screenshot (140).png>)


![alt text](<Screenshot (142).png>)


![alt text](<Screenshot (143).png>)