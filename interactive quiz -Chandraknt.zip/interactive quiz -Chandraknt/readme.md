

<!-- Responsive Design: Adapts to different screen sizes, ensuring a seamless experience on both desktop and mobile devices. -->


1)Progress Tracking: Displays the current question number and a progress bar to show quiz completion status.
2)Timer: Each question has a 30-second timer; if time runs out, a random answer is selected, and the quiz proceeds to the next question.
3)Hints: Users can view a hint for the current question .
4)Navigation: Includes "Previous" and "Next" buttons for navigating .
5)Results Display: Shows the final score, a performance message, and detailed results indicating correct/incorrect answers.
Restart Option: Allows users to restart the quiz from the beginning.

<!--
HOW TO RUN -->

Open index.html in a web browser. No additional server setup .

Notes

The quiz automatically starts when the page loads.
If the timer expires, a random answer is selected, and the quiz proceeds to the next question.
The quiz is designed to be accessible and user-friendly, with hover effects, smooth transitions.



images  from question 1 to ques 5 and ans and score


![alt text](<Screenshot (146).png>)

![alt text](<Screenshot (145).png>)


![alt text](<Screenshot (147).png>)


![alt text](<Screenshot (148).png>)



![alt text](<Screenshot (149).png>)




![alt text](<Screenshot (150).png>)




![alt text](<Screenshot (151).png>)


![alt text](<Screenshot (152).png>)